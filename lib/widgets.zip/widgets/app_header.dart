import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../utils/app_colors.dart';
import '../utils/app_constants.dart';

class AppHeader extends StatelessWidget {
  final String city;
  final String region;
  final String country;

  const AppHeader({
    super.key,
    required this.city,
    required this.region,
    required this.country,
  });

  String getGreeting() {
    final hour = DateTime.now().hour;

    if (hour < 12) {
      return AppConstants.morning;
    } else if (hour < 17) {
      return AppConstants.afternoon;
    } else if (hour < 21) {
      return AppConstants.evening;
    }

    return AppConstants.night;
  }

  @override
  Widget build(BuildContext context) {
    final today = DateFormat('EEEE, dd MMMM yyyy').format(DateTime.now());

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Text(
          getGreeting(),
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),

        const SizedBox(height: 6),

        Text(
          today,
          style: const TextStyle(
            color: Colors.white60,
            fontSize: 14,
          ),
        ),

        const SizedBox(height: 25),

        Row(
          children: [

            Container(
              height: 65,
              width: 65,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.18),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(
                Icons.location_on,
                color: Colors.white,
                size: 34,
              ),
            ),

            const SizedBox(width: 16),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Text(
                    city,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 4),

                  Text(
                    "$region, $country",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}
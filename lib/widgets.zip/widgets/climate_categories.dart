import 'package:flutter/material.dart';

class ClimateCategories extends StatelessWidget {
  final String selectedWeather;

  const ClimateCategories({
    super.key,
    required this.selectedWeather,
  });

  @override
  Widget build(BuildContext context) {
    final categories = [
      {
        "title": "Sunny",
        "icon": Icons.wb_sunny_rounded,
        "color": Colors.orange,
      },
      {
        "title": "Rainy",
        "icon": Icons.umbrella_rounded,
        "color": Colors.blue,
      },
      {
        "title": "Cloudy",
        "icon": Icons.cloud_rounded,
        "color": Colors.grey,
      },
      {
        "title": "Windy",
        "icon": Icons.air_rounded,
        "color": Colors.cyan,
      },
      {
        "title": "Storm",
        "icon": Icons.thunderstorm_rounded,
        "color": Colors.deepPurple,
      },
      {
        "title": "Snow",
        "icon": Icons.ac_unit_rounded,
        "color": Colors.lightBlue,
      },
      {
        "title": "Mist",
        "icon": Icons.foggy,
        "color": Colors.blueGrey,
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Weather Categories",
          style: TextStyle(
            color: Colors.white,
            fontSize: 21,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 16),

        SizedBox(
          height: 110,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (context, index) {
              final item = categories[index];

              final isSelected = selectedWeather
                  .toLowerCase()
                  .contains(item["title"].toString().toLowerCase());

              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 95,
                decoration: BoxDecoration(
                  color: isSelected
                      ? (item["color"] as Color).withOpacity(.28)
                      : Colors.white.withOpacity(.14),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: isSelected
                        ? item["color"] as Color
                        : Colors.white24,
                    width: 1.2,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      item["icon"] as IconData,
                      color: item["color"] as Color,
                      size: 34,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      item["title"] as String,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
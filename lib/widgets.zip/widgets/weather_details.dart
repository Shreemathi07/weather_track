import 'package:flutter/material.dart';

import '../models/weather_model.dart';

class WeatherDetails extends StatelessWidget {
  final WeatherModel? weather;

  const WeatherDetails({
    super.key,
    required this.weather,
  });

  @override
  Widget build(BuildContext context) {
    if (weather == null) {
      return const SizedBox();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Today's Highlights",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 18),

        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 15,
          mainAxisSpacing: 15,
          childAspectRatio: 1.25,
          children: [
            _buildCard(
              Icons.water_drop_rounded,
              "Humidity",
              "${weather!.humidity}%",
              Colors.blue,
            ),
            _buildCard(
              Icons.thermostat_rounded,
              "Feels Like",
              "${weather!.feelsLike.toStringAsFixed(1)}°C",
              Colors.orange,
            ),
            _buildCard(
              Icons.air_rounded,
              "Wind Speed",
              "${weather!.windSpeed.toStringAsFixed(1)} km/h",
              Colors.cyan,
            ),
            _buildCard(
              Icons.visibility_rounded,
              "Visibility",
              "${weather!.visibility.toStringAsFixed(1)} km",
              Colors.teal,
            ),
            _buildCard(
              Icons.cloud_rounded,
              "Cloud Cover",
              "${weather!.cloud}%",
              Colors.grey,
            ),
            _buildCard(
              Icons.wb_sunny_rounded,
              "UV Index",
              weather!.uvIndex.toStringAsFixed(1),
              Colors.amber,
            ),
            _buildCard(
              Icons.speed_rounded,
              "Pressure",
              "${weather!.pressure.toStringAsFixed(0)} mb",
              Colors.deepPurple,
            ),
            _buildCard(
              Icons.update_rounded,
              "Updated",
              weather!.lastUpdated,
              Colors.green,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCard(
    IconData icon,
    String title,
    String value,
    Color iconColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.16),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Colors.white24,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: iconColor.withOpacity(.18),
            child: Icon(
              icon,
              color: iconColor,
              size: 28,
            ),
          ),

          const SizedBox(height: 14),

          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 6),

          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}